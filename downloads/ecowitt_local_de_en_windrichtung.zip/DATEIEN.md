# Geänderte/neue Repository-Dateien

Basis: 39909129e5acb58d04287b8aecd1fabe710112d3

- `custom_components/ecowitt_local/__init__.py`
- `custom_components/ecowitt_local/binary_sensor.py`
- `custom_components/ecowitt_local/button.py`
- `custom_components/ecowitt_local/const.py`
- `custom_components/ecowitt_local/coordinator.py`
- `custom_components/ecowitt_local/device_naming.py`
- `custom_components/ecowitt_local/localization.py`
- `custom_components/ecowitt_local/sensor.py`
- `custom_components/ecowitt_local/strings.json`
- `custom_components/ecowitt_local/translations/de.json`
- `custom_components/ecowitt_local/translations/en.json`
- `tests/test_binary_localization.py`
- `tests/test_device_localization.py`
- `tests/test_direction.py`
- `tests/test_localization.py`
- `tests/test_localized_setup.py`
- `tests/test_statistics_preservation.py`

11 Integrationsdateien und 6 neue Testdateien. Alle sind im Paket vollständig enthalten.
Patch-Anwendung gegen den Basisstand und bytegenaue Übereinstimmung wurden geprüft.
