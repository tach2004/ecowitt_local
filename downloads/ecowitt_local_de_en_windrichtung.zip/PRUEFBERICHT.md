# Prüfbericht: Ecowitt Local Deutsch/Englisch und Richtungspfeile

Stand: 10. November 2026. Basis: Fork `tach2004/ecowitt_local`, Commit
`39909129e5acb58d04287b8aecd1fabe710112d3`, Integration 1.11.0.

## Ergebnis

Die vollständige Haupttestsuite besteht: **634 Tests, 100 % Zeilenabdeckung**
für die Integration (2.410 erfasste Anweisungen, keine ungetestet).
Gegenüber den ursprünglichen 518 Tests wurden 116 Testfälle ergänzt.
Die Zeilenabdeckung ist ein Prüfergebnis, keine Garantie für jede denkbare
Geräte-/Firmwarekombination.

| Prüfung | Umgebung | Ergebnis |
| --- | --- | --- |
| Vollständige Testsuite | Python 3.13.17, HA 2026.2.3, Testplugin 0.13.316 | 634 bestanden, 100 % Coverage |
| Alle 116 neuen Testfälle | Python 3.14.9, HA 2026.10.4, Testplugin 0.13.375 | 116 bestanden |
| Direkter Laufzeittest ohne HA-Testplugin | Python 3.14.9, HA 2026.11.1 | Englisch/Deutsch bestanden |
| Originale hassfest-Prüfer für Übersetzungen, Manifest und Services | HA 2026.1.0 und 2026.2.3 | Keine Fehler oder Warnungen |
| Offizielles Übersetzungsschema für strings.json, en.json und de.json | HA 2026.1.0 und 2026.2.3 | Alle akzeptiert |
| Tatsächlicher HA-Frontend-Iconresolver mit nativen Icondefinitionen | HA 2026.1.0 und 2026.2.3 | Je 25 Winkel-/Grenz-/Fehlerfälle bestanden |
| Black, isort, mypy, strenge flake8-Fehlerauswahl, Git-Whitespaceprüfung | Hauptumgebung | Alle bestanden |

Der Laufzeittest unter 2026.11.1 prüft den echten Übersetzungsloader für alle
sechs Kategorien sowie tatsächliche Sensor-, Binärsensor- und Buttoninstanzen,
Namen, IDs, Werte, Einheiten und die vier Windrichtungsklassen. Er ist kein
vollständiger Gateway-/Frontend-/Datenbanktest dieser Version.

## Bestehende IDs, Verlauf und Statistiken

Der neue Upgrade-Test legt vor der Einrichtung bereits registrierte Geräte und
eine manuell benannte Entität unter `sensor.freezer_probe` an. Er prüft vor und
nach deutschem Setup und erneutem Laden:

- dieselbe Registry-ID, Entitäts-ID und Unique-ID;
- dieselbe Gerätezuordnung und unveränderte selbst vergebene Namen;
- denselben Satz von Entitäts-IDs, ohne zusätzliche `_2`-Entitäten;
- unveränderte Messwerte, Einheiten, Geräte- und Zustandsklassen.

Der zusätzliche Recorder-Test verwendet eine echte temporäre SQLite-Datei:

1. Zwei historische Stundenwerte werden unter der bestehenden Entitäts-ID gespeichert.
2. Die Integration wird tatsächlich von Englisch auf Deutsch neu geladen.
3. Historische Werte und der Primärschlüssel des Statistik-Metadatensatzes bleiben gleich.
4. Der echte HA-Statistikcompiler erzeugt anschließend neue 5-Minuten-Statistikwerte
   unter derselben Statistik-ID.
5. Der echte Verlauf enthält beide Anzeigenamen unter derselben Entitäts-ID.

Zusätzlich werden eigene HA-Gerätenamen, Gateway-Custom-Titel, das Löschen eines
solchen Titels, bestehende Bereichszuordnungen, doppelte Hardware-IDs auf
unterschiedlichen Kanälen und zur Laufzeit neu hinzukommende Sensoren geprüft.
Die bestehende Berechnung technischer IDs und die Migrationslogik wurden nicht geändert.

## Übersetzung

Englisch und Deutsch enthalten dieselben Schlüssel und Platzhalter; `strings.json`
entspricht `en.json`. Je Sprache gibt es 2.751 Textwerte einschließlich wiederholter
Attributlabels: 129 Sensor-, 12 Binärsensor-, 24 Geräte-, ein Button- und sechs
Exception-Schlüssel sowie die bisherigen Dialog- und Aktionstexte.

Geprüft sind UTF-8, doppelte Schlüssel, leere Werte, Platzhalter, Kanalvarianten,
alle vorhandenen statischen Sensor-/Batterienamen, generierte Diagnosen und
die zur Laufzeit wechselnden Solar-Bezeichnungen. Alle bisherigen englischen
Namensvorlagen bleiben gleich. Vorhandene weitere Sprachen funktionieren mit
englischem Fallback für neue Texte.

Namen folgen der System-/Backend-Sprache. Dialoge und Attributanzeigen können
zusätzlich der Benutzerprofil-/Frontend-Sprache folgen. Nach einem Wechsel der
Systemsprache ist ein Neuladen der Integration bzw. Neustart vorgesehen.
Eigene Namen, Modellkennungen, Rohdaten und technische Attributschlüssel bleiben erhalten.

## Windrichtungspfeile

Verglichen wurde die Ecowitt-Referenzintegration
https://github.com/Ecowitt/ha-ecowitt-iot, Commit `f73b3a1`.
Sie verwendet die native HA-Geräteklasse `wind_direction`. Dieselbe Klasse wird
für die vier vorhandenen Richtungsschlüssel ergänzt. Die Einheit Grad und die
Zustandsklasse `measurement_angle` bleiben unverändert.

Die ursprünglichen HA-Frontend-Resolverfunktionen wurden mit den originalen
Icondefinitionen geprüft, einschließlich 0°/360°, Sektorgrenzen sowie unbekannten
und nicht verfügbaren Werten. Es wurde keine fremde Iconimplementierung in den
Integrationscode kopiert und keine zusätzliche Laufzeitabhängigkeit eingeführt.

## Grenzen der neueren vollständigen Testumgebung

Unter HA 2026.10.4 scheitern bereits im unveränderten Fork 75 der ursprünglichen
Tests; zwei weitere haben Teardown-Fehler. Die Ursachen sind überwiegend die
ältere HTTP-Mockbibliothek gegenüber der neueren aiohttp-API und veraltete
Registry-Aufrufe in den ursprünglichen Tests. Diese Fehler wurden ausdrücklich
gegen einen separaten unveränderten Checkout desselben Fork-Commits verglichen.

Alle 116 neu hinzugefügten Tests bestehen in dieser Umgebung. Für einen pauschalen
Erfolg der vollständigen Suite unter 2026.10.4 wird kein Anspruch erhoben.
Es wurden keine Dependency-Pins umgangen und keine Integrationsfunktionen nur
zur Anpassung an ein inkompatibles Testwerkzeug geändert.

Die offizielle hassfest-Prüfung umfasste die drei genannten unveränderten
Prüfmodule und das Übersetzungsschema. Der vollständige hassfest-CLI mit allen
anderen Plugins wurden nicht ausgeführt. Die hier aufgeführten Ergebnisse stammen
aus den lokalen Prüfungen vor der Veröffentlichung. Die GitHub-Checks des
anschließenden Fork-PRs werden separat im PR angezeigt; deren Status wird hier
nicht vorweggenommen.

Ein physisches Gateway und deine bestehende HA-Datenbank standen hier nicht zur
Verfügung. Deshalb bleibt dein vorgesehener Gerätetest vor einem späteren PR nötig.
Die beigefügten Protokolle dokumentieren die ausgeführten Prüfungen.

## Hauptprüfung wiederholen

In einem Checkout mit passend eingerichteter Testumgebung:

```sh
PYTHONPATH="$PWD" .venv/bin/pytest tests/ --cov=custom_components.ecowitt_local --cov-report=term-missing
.venv/bin/black --check custom_components/ecowitt_local/ tests/
.venv/bin/isort --check-only custom_components/ecowitt_local/ tests/
.venv/bin/mypy custom_components/ecowitt_local/ --follow-imports=silent --ignore-missing-imports
.venv/bin/flake8 custom_components/ecowitt_local --count --select=E9,F63,F7,F82 --show-source --statistics
git diff --check
```

Die Hauptprüfung verwendete HA 2026.2.3 und
`pytest-homeassistant-custom-component==0.13.316` unter Python 3.13.17.
Weitere relevante Paketversionen stehen unter `pruefungen/umgebung.json`.
