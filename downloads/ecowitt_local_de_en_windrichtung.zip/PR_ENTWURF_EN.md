# Add complete English/German UI localization and native wind direction icons

Ecowitt Local currently translates configuration dialogs and services, while
sensor, diagnostic, button and device names are generated in English. This change
adds complete English and German catalogs and connects generated display names
and known attribute labels to Home Assistant's translation system. Existing
English names, user-defined names, entity IDs, unique IDs, device associations,
units and state classes are preserved.

The four existing wind direction keys receive Home Assistant's native
`wind_direction` device class. This enables the same dynamic frontend MDI arrows
used by Ecowitt's integration, without introducing a custom icon algorithm or
changing angle values.

Validation includes the existing suite and new tests for both languages,
fallback languages, existing registry entries and custom entity IDs, device
titles, runtime solar-unit changes, unavailable direction values and recorded
statistics surviving an English-to-German reload. See the accompanying validation
report for exact versions and results.

Entity and device names follow Home Assistant's system language. Configuration
dialogs follow the frontend user's language. Reload the integration after
changing the system language. This contribution leaves release versioning to
the maintainer.
