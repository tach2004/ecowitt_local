"""Sensor platform for Ecowitt Local integration."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Dict, Optional

from homeassistant.components.sensor import (
    SensorDeviceClass,
    SensorEntity,
    SensorStateClass,
)
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import (
    ATTR_BATTERY_LEVEL,
    PERCENTAGE,
    UnitOfIrradiance,
    UnitOfLength,
    UnitOfPrecipitationDepth,
    UnitOfPressure,
    UnitOfSpeed,
    UnitOfTemperature,
    UnitOfVolumetricFlux,
)
from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers.entity import DeviceInfo, EntityCategory
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import (
    ATTR_BATTERY_LEVEL,
    ATTR_CHANNEL,
    ATTR_DEVICE_MODEL,
    ATTR_FIRMWARE_VERSION,
    ATTR_HARDWARE_ID,
    ATTR_SENSOR_TYPE,
    ATTR_SIGNAL_STRENGTH,
    BATTERY_SENSORS,
    DOMAIN,
    MANUFACTURER,
    SENSOR_TYPES,
)
from .coordinator import EcowittLocalDataUpdateCoordinator
from .device_compat import via_device_kwargs
from .device_naming import device_name_kwargs, gateway_name_kwargs, is_outdoor_sensor
from .localization import (
    LocalizedEntityNameMixin,
    name_translation_spec,
    translated_text,
)

_LOGGER = logging.getLogger(__name__)

# Unit conversion mappings
UNIT_CONVERSIONS = {
    "°F": UnitOfTemperature.FAHRENHEIT,
    "°C": UnitOfTemperature.CELSIUS,
    "inHg": UnitOfPressure.INHG,
    "hPa": UnitOfPressure.HPA,
    "mph": UnitOfSpeed.MILES_PER_HOUR,
    "km/h": UnitOfSpeed.KILOMETERS_PER_HOUR,
    "in": UnitOfLength.INCHES,
    "mm": UnitOfLength.MILLIMETERS,
    "in/hr": UnitOfVolumetricFlux.INCHES_PER_HOUR,
    "mm/hr": UnitOfVolumetricFlux.MILLIMETERS_PER_HOUR,
    "W/m²": UnitOfIrradiance.WATTS_PER_SQUARE_METER,
}


async def async_setup_entry(
    hass: HomeAssistant,
    config_entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up Ecowitt Local sensor entities."""
    coordinator = hass.data[DOMAIN][config_entry.entry_id]

    known_entity_ids: set[str] = set()

    @callback
    def _async_add_new_entities() -> None:
        """Add entities for sensor keys that were not present at a previous poll.

        A sensor with a flaky RF link can be briefly absent from coordinator
        data at platform setup time; without this, its entity would never be
        created and would stay stuck in a stale "restored" state forever
        (issue #207).
        """
        sensor_data = coordinator.get_all_sensors()
        new_entities = []
        for entity_id, sensor_info in sensor_data.items():
            if entity_id in known_entity_ids:
                continue
            category = sensor_info.get("category")
            if category in ("sensor", "battery", "system", "diagnostic"):
                known_entity_ids.add(entity_id)
                new_entities.append(
                    EcowittLocalSensor(coordinator, entity_id, sensor_info)
                )

        if new_entities:
            _LOGGER.info(
                "Setting up %d Ecowitt Local sensor entities", len(new_entities)
            )
            async_add_entities(new_entities, True)

    _async_add_new_entities()
    config_entry.async_on_unload(
        coordinator.async_add_listener(_async_add_new_entities)
    )


class EcowittLocalSensor(
    LocalizedEntityNameMixin,
    CoordinatorEntity[EcowittLocalDataUpdateCoordinator],
    SensorEntity,
):
    """Representation of an Ecowitt Local sensor."""

    _translation_platform = "sensor"

    def __init__(
        self,
        coordinator: EcowittLocalDataUpdateCoordinator,
        entity_id: str,
        sensor_info: Dict[str, Any],
    ) -> None:
        """Initialize the sensor."""
        super().__init__(coordinator)

        self.entity_id = entity_id
        self._sensor_key = sensor_info["sensor_key"]
        self._hardware_id = sensor_info.get("hardware_id")
        self._category = sensor_info.get("category", "sensor")

        # Set unique ID based on hardware ID if available
        if self._hardware_id:
            self._attr_unique_id = f"{DOMAIN}_{self._hardware_id}_{self._sensor_key}"
        else:
            self._attr_unique_id = (
                f"{DOMAIN}_{self.coordinator.config_entry.entry_id}_{self._sensor_key}"
            )

        # Set entity category: diagnostic sensors, or sensors with explicit entity_category
        if self._category == "diagnostic":
            self._attr_entity_category = EntityCategory.DIAGNOSTIC
        elif sensor_info.get("entity_category") == "diagnostic":
            self._attr_entity_category = EntityCategory.DIAGNOSTIC

        # Set entity as disabled by default if specified
        if sensor_info.get("enabled_default") is False:
            self._attr_entity_registry_enabled_default = False

        # Set suggested display precision if provided
        precision = sensor_info.get("suggested_display_precision")
        if precision is not None:
            self._attr_suggested_display_precision = precision

        # Entities on their own hardware-ID device are named by what they measure;
        # HA prefixes the device name (issues #244, #262). Without a hardware device
        # they keep their standalone name (with the channel, where there is one) so
        # they stay distinct. Decided once here, together with the device the entity
        # registers under.
        sensor_def = (
            BATTERY_SENSORS.get(self._sensor_key)
            or SENSOR_TYPES.get(self._sensor_key)
            or {}
        )
        # The coordinator may supply entity_name for entities it renames or derives
        # at runtime (solar radiation in lux mode); that wins over the static one.
        self._entity_name: Optional[str] = sensor_def.get("entity_name")
        self._use_entity_name = bool(
            (sensor_info.get("entity_name") or self._entity_name)
            and self._hardware_sensor_info() is not None
        )
        self._attr_has_entity_name = self._use_entity_name

        # Set initial attributes
        self._update_attributes(sensor_info)

    def _hardware_sensor_info(self) -> Optional[Dict[str, Any]]:
        """Return mapping info if this entity belongs to its own hardware device."""
        if not self._hardware_id or self._hardware_id.upper() in (
            "FFFFFFFE",
            "FFFFFFFF",
            "00000000",
        ):
            return None
        info: Optional[Dict[str, Any]] = self.coordinator.sensor_mapper.get_sensor_info(
            self._hardware_id
        )
        return info

    def _update_attributes(self, sensor_info: Dict[str, Any]) -> None:
        """Update sensor attributes from sensor info."""
        self._attr_name = (
            sensor_info.get("entity_name") or self._entity_name
            if self._use_entity_name
            else sensor_info.get("name", self._sensor_key)
        )
        if self._attr_name is not None:
            (
                self._attr_translation_key,
                self._attr_translation_placeholders,
            ) = name_translation_spec(self._attr_name)
        self._attr_native_value = sensor_info.get("state")

        # Set unit of measurement
        unit = sensor_info.get("unit_of_measurement")
        if unit:
            self._attr_native_unit_of_measurement = UNIT_CONVERSIONS.get(unit, unit)
        else:
            self._attr_native_unit_of_measurement = None

        # Set device class
        device_class_str = sensor_info.get("device_class")
        if device_class_str:
            try:
                self._attr_device_class = SensorDeviceClass(device_class_str)
            except ValueError:
                _LOGGER.debug("Unknown device class: %s", device_class_str)
                self._attr_device_class = None

        # Set state class — read from sensor_info (SENSOR_TYPES) first, fall back to device_class logic
        state_class_str = sensor_info.get("state_class")
        if state_class_str:
            try:
                self._attr_state_class = SensorStateClass(state_class_str)
            except ValueError:
                _LOGGER.debug("Unknown state class: %s", state_class_str)
                self._attr_state_class = None
        elif (
            isinstance(self._attr_native_value, (int, float))
            and self._attr_native_value is not None
        ):
            if self._category == "battery":
                self._attr_state_class = SensorStateClass.MEASUREMENT
            elif device_class_str in (
                "temperature",
                "humidity",
                "pressure",
                "wind_speed",
                "precipitation_intensity",
                "irradiance",
                "pm25",
                "moisture",
            ):
                self._attr_state_class = SensorStateClass.MEASUREMENT

        # For timestamp device class, convert naive string to timezone-aware datetime.
        # The gateway reports timestamps in its configured local time (matching the
        # weather station's clock), not UTC, so attach HA's local timezone to naive
        # values rather than UTC — otherwise the entity is offset by the user's UTC
        # offset (issue #153).
        if device_class_str == "timestamp" and isinstance(self._attr_native_value, str):
            import homeassistant.util.dt as dt_util

            try:
                dt = datetime.fromisoformat(self._attr_native_value)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=dt_util.DEFAULT_TIME_ZONE)
                self._attr_native_value = dt
            except (ValueError, TypeError):
                self._attr_native_value = None

        # Set battery sensor specific attributes (now diagnostic category)
        if device_class_str == "battery":
            self._attr_device_class = SensorDeviceClass.BATTERY
            self._attr_native_unit_of_measurement = PERCENTAGE
            self._attr_state_class = SensorStateClass.MEASUREMENT

    @callback
    def _handle_coordinator_update(self) -> None:
        """Handle updated data from the coordinator."""
        # Primary: look up by sensor_key + hardware_id. This is stable regardless of
        # whether the entity's registry entity_id matches the coordinator's generated
        # entity_id (they can diverge when entity_id format changes between versions).
        sensor_info = self.coordinator.get_sensor_data_by_key(
            self._sensor_key, self._hardware_id
        )
        if sensor_info is None:
            sensor_info = self.coordinator.get_sensor_data(self.entity_id)
        if sensor_info:
            self._update_attributes(sensor_info)
        self.async_write_ha_state()

    @property
    def device_info(self) -> DeviceInfo:
        """Return device information."""
        gateway_info = self.coordinator.gateway_info
        gateway_id = gateway_info.get("gateway_id", "unknown")

        # If this sensor has a hardware ID, create individual device
        if self._hardware_id and self._hardware_id.upper() not in (
            "FFFFFFFE",
            "FFFFFFFF",
            "00000000",
        ):
            sensor_info = self._hardware_sensor_info()
            _LOGGER.debug(
                "Sensor %s: hardware_id=%s, sensor_info=%s",
                self._sensor_key,
                self._hardware_id,
                bool(sensor_info),
            )
            if sensor_info:
                device_model = sensor_info.get("device_model") or sensor_info.get(
                    "sensor_type", "Unknown"
                )
                _LOGGER.debug(
                    "Sensor %s using individual device: %s",
                    self._sensor_key,
                    self._hardware_id,
                )
                return DeviceInfo(
                    identifiers={(DOMAIN, self._hardware_id)},
                    **device_name_kwargs(self._hardware_id, sensor_info),
                    manufacturer=MANUFACTURER,
                    model=device_model,
                    suggested_area=(
                        translated_text(self.hass, "device", "outdoor.name", "Outdoor")
                        if is_outdoor_sensor(sensor_info.get("sensor_type", ""))
                        else None
                    ),
                    **via_device_kwargs(self.hass, gateway_id),
                )
            else:
                _LOGGER.debug(
                    "Sensor %s has hardware_id %s but no sensor info found",
                    self._sensor_key,
                    self._hardware_id,
                )

        # Fall back to gateway device for built-in sensors
        _LOGGER.debug(
            "Sensor %s using gateway device (hardware_id: %s)",
            self._sensor_key,
            self._hardware_id,
        )
        return DeviceInfo(
            identifiers={(DOMAIN, gateway_id)},
            **gateway_name_kwargs(gateway_info),
            manufacturer=MANUFACTURER,
            model=gateway_info.get("model", "Unknown"),
            sw_version=gateway_info.get("firmware_version", "Unknown"),
            configuration_url=f"http://{gateway_info.get('host', '')}",
        )

    @property
    def extra_state_attributes(self) -> Dict[str, Any]:
        """Return additional state attributes."""
        sensor_info = self.coordinator.get_sensor_data_by_key(
            self._sensor_key, self._hardware_id
        )
        if sensor_info is None:
            sensor_info = self.coordinator.get_sensor_data(self.entity_id)
        if not sensor_info:
            return {}

        attributes = sensor_info.get("attributes", {})

        # Add standard attributes
        extra_attrs = {
            "sensor_key": self._sensor_key,
            "category": self._category,
        }

        # Add hardware-specific attributes if available
        if self._hardware_id:
            extra_attrs[ATTR_HARDWARE_ID] = self._hardware_id

            # Add hardware-specific details
            if attributes.get("channel"):
                extra_attrs[ATTR_CHANNEL] = attributes["channel"]
            if attributes.get("device_model"):
                extra_attrs[ATTR_DEVICE_MODEL] = attributes["device_model"]
            # For battery entities: export the entity's own state as battery_level so
            # Battery State Card and HA battery dashboard read the correct percentage.
            # We no longer propagate the raw batt bar from sensors_info (which was 0-5,
            # not 0-100) because that caused Battery State Card to show e.g. 5% instead
            # of 100% for a full WH90 battery.
            if (
                self.device_class == SensorDeviceClass.BATTERY
                and self._attr_native_value is not None
            ):
                try:
                    extra_attrs[ATTR_BATTERY_LEVEL] = float(self._attr_native_value)
                except (ValueError, TypeError):
                    pass
            if attributes.get("signal"):
                try:
                    signal_strength = int(attributes["signal"])
                    extra_attrs[ATTR_SIGNAL_STRENGTH] = signal_strength
                except (ValueError, TypeError):
                    pass

        # Add sensor type
        extra_attrs[ATTR_SENSOR_TYPE] = self._category

        # Add raw value for debugging
        if "raw_value" in sensor_info:
            extra_attrs["raw_value"] = sensor_info["raw_value"]

        return extra_attrs

    @property
    def available(self) -> bool:
        """Return if entity is available."""
        if not self.coordinator.last_update_success:
            return False

        # Primary: look up by sensor_key + hardware_id (stable across entity_id format changes)
        sensor_info = self.coordinator.get_sensor_data_by_key(
            self._sensor_key, self._hardware_id
        )
        if sensor_info is None:
            sensor_info = self.coordinator.get_sensor_data(self.entity_id)
        if not sensor_info:
            return False

        # If we have a hardware ID and the sensor value is None,
        # it might be offline
        if self._hardware_id and sensor_info.get("state") is None:
            # Check if we should include inactive sensors
            include_inactive = self.coordinator.config_entry.data.get(
                "include_inactive", False
            )
            return bool(include_inactive)

        return True

    @property
    def icon(self) -> Optional[str]:
        """Return the icon for the sensor."""
        # Custom icons based on device class (battery sensors are in diagnostic category)
        if self.device_class == SensorDeviceClass.BATTERY:
            # Use battery icon based on level
            battery_level = self.extra_state_attributes.get(ATTR_BATTERY_LEVEL)
            if battery_level is not None:
                if battery_level <= 10:
                    return "mdi:battery-outline"
                elif battery_level <= 20:
                    return "mdi:battery-20"
                elif battery_level <= 30:
                    return "mdi:battery-30"
                elif battery_level <= 40:
                    return "mdi:battery-40"
                elif battery_level <= 50:
                    return "mdi:battery-50"
                elif battery_level <= 60:
                    return "mdi:battery-60"
                elif battery_level <= 70:
                    return "mdi:battery-70"
                elif battery_level <= 80:
                    return "mdi:battery-80"
                elif battery_level <= 90:
                    return "mdi:battery-90"
                else:
                    return "mdi:battery"
            return "mdi:battery"

        if self._sensor_key.startswith("signal_quality_"):
            quality = self._attr_native_value
            if isinstance(quality, (int, float)):
                if quality >= 75:
                    return "mdi:signal-cellular-3"
                elif quality >= 50:
                    return "mdi:signal-cellular-2"
                elif quality >= 25:
                    return "mdi:signal-cellular-1"
                else:
                    return "mdi:signal-cellular-outline"
            return "mdi:signal-cellular-outline"

        # Use device class icons or custom ones
        sensor_icons = {
            "soil": "mdi:sprout",
            "leak": "mdi:water-alert",
            "lightning": "mdi:flash",
            "uv": "mdi:weather-sunny-alert",
            "heap": "mdi:memory",
            "runtime": "mdi:clock-outline",
        }

        for key, icon in sensor_icons.items():
            if key in self._sensor_key.lower():
                return icon

        return None
