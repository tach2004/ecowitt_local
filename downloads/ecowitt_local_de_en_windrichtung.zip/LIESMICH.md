# Ecowitt Local: Deutsch/Englisch und Windrichtungspfeile

Dieses Paket enthält die vollständigen neuen und geänderten Dateien für den Fork
https://github.com/tach2004/ecowitt_local.

Basis: Ecowitt Local 1.11.0, Fork-Commit
`39909129e5acb58d04287b8aecd1fabe710112d3`.
Die bereits hochgeladene erste `de.json` ist darin enthalten und wird durch die
erweiterte Datei ersetzt.

## Inhalt

- `repository/custom_components/ecowitt_local/`: neue/geänderte Integrationsdateien.
- `repository/tests/`: zusätzliche automatisierte Regressionstests für den späteren PR.
- `AENDERUNGEN.patch`: derselbe Änderungssatz als Git-Patch gegen den oben genannten Fork-Stand.
- `PRUEFBERICHT.md`: tatsächlich ausgeführte Prüfungen und deren Grenzen.
- `PR_ENTWURF_EN.md`: englischer Textentwurf für einen späteren PR; es wurde keiner erstellt.
- `SHA256SUMS.txt`: Prüfsummen der übrigen Dateien im Paket.

Der Ordner `repository` enthält einen Änderungssatz, kein vollständiges Repository.
Vorhandene unveränderte Dateien werden weiterhin benötigt.

## In deinen Fork übernehmen

Kopiere den Inhalt von `repository` in das Hauptverzeichnis deines vorhandenen
Fork-Checkouts. Ergänze neue Dateien und überschreibe die gleichnamigen Dateien.
Die Dateien unter `custom_components` und `tests` gehören zum Codebeitrag.
Die Begleitdokumente außerhalb von `repository` können außerhalb des Forks bleiben.

Manifest-Version und Migrationslogik wurden nicht verändert. Das Paket ist eine
lokale Testfassung auf Basis von 1.11.0, kein veröffentlichtes Release.
Die Veröffentlichung erfolgt in einem eigenen Featurebranch deines Forks.
Der zugehörige PR richtet sich ausschließlich gegen `tach2004/ecowitt_local:main`.
Ein PR beim ursprünglichen Anbieter und ein Release sind nicht Teil dieses Schritts.

## In der vorhandenen Home-Assistant-Installation testen

1. Sichere den bestehenden Ordner `/config/custom_components/ecowitt_local`.
2. Kopiere **alle Dateien** aus `repository/custom_components/ecowitt_local`
   in diesen bestehenden Ordner. Die vorhandenen unveränderten Dateien müssen
   dort bleiben: den alten Ordner ergänzen/überschreiben, nicht vorher löschen.
   Falls dein Konfigurationsverzeichnis anders heißt, passe `/config` entsprechend an.
3. Für deutsche Sensor- und Gerätenamen stelle die **Systemsprache** in Home
   Assistant auf Deutsch, üblicherweise unter Einstellungen → System → Allgemein.
4. Starte Home Assistant vollständig neu. Die bestehende Integration bleibt
   eingerichtet. Lösche sie zum Testen nicht und lege sie nicht erneut an.
5. Für deutsche Einrichtungstexte und Aktionen wähle zusätzlich Deutsch als
   Sprache in deinem Benutzerprofil und lade den Browser neu.

Ein Profilsprachwechsel allein ändert keine vom Backend erzeugten Sensor- oder
Gerätenamen. Nach einem späteren Wechsel der Systemsprache lade die Integration
neu oder starte Home Assistant neu.

Nur die `de.json` zu ersetzen genügt für die Sensor- und Gerätenamen nicht;
die Python-Dateien und die Sprachdateien müssen zusammen aktualisiert werden.
HACS kann lokale Änderungen bei einem erneuten Download oder Update überschreiben.

## Was übersetzt wird

Alle vorhandenen Integrationsdialoge, Optionen, Fehlermeldungen, Aktionen,
Messsensoren, Batterien, Diagnosen, Binärsensoren, der Resync-Button,
automatischen Gerätenamen sowie die bekannten Anzeigenamen zusätzlicher Attribute.
Englisch bleibt vollständig vorhanden; die bisherigen englischen Namen bleiben
gleich. Die vorhandenen weiteren Sprachen verwenden für neue Texte den
englischen Fallback.

Eigene Namen in Home Assistant und die benutzerdefinierten Gateway-Titel bleiben
erhalten. Modellnummern, Hardware-IDs, technische Attributschlüssel, Rohwerte und
Diagnosedetails wie Betriebssystem-Fehlermeldungen bleiben technische Daten.
Logs bleiben wie im ursprünglichen Projekt Englisch; sichtbare HA-Fehler erhalten
zusätzlich deutsche Übersetzungsmetadaten.

## IDs, Historie und Statistiken

Entitäts-IDs, Unique-IDs und Gerätekennungen behalten ihre bisherige Berechnung.
Es gibt keine Umbenennung dieser IDs und keine neue Datenmigration.
Die Namensübersetzung verändert den Anzeigenamen. Selbst vergebene Namen und
bestehende Bereichszuordnungen werden beibehalten.

Ein echter HA-Upgrade-/Reload-Test prüft bereits registrierte, manuell benannte
Entitäten. Ein zusätzlicher SQLite-Recorder-Test prüft den Erhalt gespeicherter
Langzeitstatistiken und ihrer Metadaten-ID beim Wechsel von Englisch auf Deutsch.
Die Details stehen im Prüfbericht. Deine reale Datenbank wurde nicht verändert
oder hier eingelesen.

## Richtungspfeile

Alle vier vorhandenen Richtungsschlüssel erhalten die native Home-Assistant-
Geräteklasse `wind_direction`: `winddir`, `winddir_avg10m`, `0x0A` und `0x6D`.
Home Assistant wählt daraus selbst die passenden dynamischen MDI-Pfeile, genau
wie bei der verglichenen Ecowitt-Integration. Numerische Werte, Grad-Einheit und
Zustandsklasse `measurement_angle` bleiben erhalten.

Die Pfeile zeigen die Strömungsrichtung: Nordwind bei 0° zeigt nach unten,
Ostwind bei 90° nach links, Südwind bei 180° nach oben und Westwind bei 270° nach
rechts. Ein manuell gesetztes Icon kann diese automatische Anzeige übersteuern.
HA berechnet das Icon im Frontend; ein zusätzliches festes `icon`-Attribut ist
dafür nicht nötig.

## Kurzer Gerätetest

- Prüfe, dass deine bisherigen Entitäts-IDs weiterhin vorhanden sind und keine
  zusätzlichen `_2`-Entitäten entstehen.
- Prüfe automatisch benannte Messsensoren, Batterien und Diagnosen auf Deutsch.
  Selbst vergebene Namen bleiben absichtlich wie zuvor.
- Prüfe vorhandene Kurven, Langzeitstatistiken, Automationen und Dashboards.
- Prüfe aktuelle Messwerte und die regelmäßige Aktualisierung.
- Prüfe die aktuelle und die gemittelte Windrichtung einschließlich Pfeilen.
- Prüfe die Optionen und beide Aktionen unter Entwicklerwerkzeuge → Aktionen.
- Falls vorhanden, prüfe mehrere Kanalsensoren, Gateway-Custom-Titel und Solarwerte.

Für eine Rückmeldung hilfreich: Home-Assistant-Core-Version, Gateway-Modell und
Firmware, Installationsart und die konkret betroffene Entität. Zugangsdaten
werden dafür nicht benötigt.

## Rückgängig machen

Stelle die gesicherten Integrationsdateien wieder her. Entferne dabei die neu
hinzugefügte `localization.py`, falls sie nicht in deiner Sicherung vorhanden war,
und starte Home Assistant neu. Lösche weder die bestehende Integration noch
ihre Entitäten oder die Recorder-Datenbank.
